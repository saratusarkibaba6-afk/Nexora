# NEXORA — Netlify AI-ready site

This package preserves the existing NEXORA website and adds a secure Netlify Functions backend for live AI answers.

## Deploy
1. Upload the extracted contents of this folder to the root of a GitHub repository. Keep the `netlify` folder and `netlify.toml` in the root.
2. In Netlify, import the GitHub repository as a new site or connect it to the existing NEXORA site.
3. In Netlify site settings, add an environment variable named `OPENAI_API_KEY` with your private API key. Never put this key in `index.html` or any public repository file.
4. Optionally set `OPENAI_MODEL` to a model enabled for your API account. The default is `gpt-4.1-mini`.
5. Trigger a new deploy. The `/health` endpoint should respond with JSON; `/api/chat` accepts `POST` JSON `{ "message": "..." }` and returns `{ "reply": "..." }`.

The AI provider API key and any usage billing are separate from a ChatGPT subscription. Protect the key and monitor API usage.
