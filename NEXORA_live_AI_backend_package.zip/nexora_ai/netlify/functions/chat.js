const json = (statusCode, data) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  },
  body: JSON.stringify(data)
});

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return json(200, { ok: true });
  if (event.httpMethod !== "POST") return json(405, { error: "Use POST to send a message." });

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return json(503, { reply: "NEXORA's AI brain is not configured yet. The site owner must add the OPENAI_API_KEY secret in Netlify site environment variables." });

  let body;
  try { body = JSON.parse(event.body || "{}"); }
  catch { return json(400, { error: "Request body must be valid JSON." }); }

  const message = typeof body.message === "string" ? body.message.trim() : "";
  if (!message) return json(400, { error: "Please enter a question." });
  if (message.length > 12000) return json(413, { error: "Please keep each message under 12,000 characters." });

  const model = process.env.OPENAI_MODEL || "gpt-4.1-mini";
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: "You are NEXORA, a helpful, clear, respectful AI assistant and educational tutor. For academic questions, explain concepts step by step in accessible language, define important terms, use examples, and when useful end with three review questions. Be honest about uncertainty and never fabricate sources or citations. For medical, legal, financial, or other high-stakes topics, provide general educational information, not a diagnosis or professional advice, and encourage qualified professional support when appropriate. If the user message asks for a subject lesson, follow the subject and learner level specified in their message." },
          { role: "user", content: message }
        ],
        temperature: 0.5,
        max_tokens: 1800
      })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const providerMessage = data && data.error && data.error.message ? data.error.message : "The AI provider returned an error.";
      console.error("NEXORA provider error", response.status, providerMessage);
      return json(502, { reply: "NEXORA could not get an answer from the AI service just now. Please try again shortly. If the problem continues, check the API key, API billing, and model setting in Netlify." });
    }
    const reply = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
    if (typeof reply !== "string" || !reply.trim()) return json(502, { reply: "NEXORA received an empty response. Please try asking in a different way." });
    return json(200, { reply: reply.trim() });
  } catch (error) {
    console.error("NEXORA backend error", error);
    return json(502, { reply: "NEXORA could not connect to the AI service. Please check your connection and try again." });
  }
};
