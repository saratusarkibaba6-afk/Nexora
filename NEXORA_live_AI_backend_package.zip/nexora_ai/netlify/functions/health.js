exports.handler = async () => ({
  statusCode: 200,
  headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  body: JSON.stringify({ ok: true, service: "NEXORA AI backend", configured: Boolean(process.env.OPENAI_API_KEY) })
});
