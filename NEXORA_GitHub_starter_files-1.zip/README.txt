NEXORA GitHub starter files

Upload these two files to the ROOT of your GitHub repository:
1. NEXORA_live_AI_backend_package.zip
2. netlify.toml

Then connect this repository to Netlify. Netlify will extract the website and deploy its serverless AI functions during the build. Do not add your API key to GitHub. Add OPENAI_API_KEY only in Netlify site environment variables after deployment.
